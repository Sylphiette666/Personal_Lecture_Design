# 计算机网络课程设计：四个课题完整参考实现与教程

> 说明：本项目是教学参考实现。请在理解代码、完成截图、补充个人分工和调试记录后再写入课程报告。课题 3 涉及截包，只能在自己拥有或明确授权的实验网络中运行，不要截获或传播他人通信内容。

## 0. 项目结构

```text
network_course_design/
├── topic1_ping/
│   └── my_ping.py                 # 课题1：RAW socket + ICMP Ping
├── topic2_ftp/
│   ├── ftp_server.py              # 课题2：简化 FTP 服务器
│   └── ftp_client.py              # 课题2：简化 FTP 客户端
├── topic3_sniffer/
│   └── lan_sniffer.py             # 课题3：局域网截包与协议解码
├── topic4_datalink/
│   └── datalink_protocols.py      # 课题4：停止-等待、回退N、选择重发模拟
└── docs/
    ├── 答辩讲解稿.md
    └── 课程设计报告模板.md
```

## 1. 环境准备

### 1.1 安装 Python

建议使用 Python 3.9 或以上版本。查看版本：

```bash
python --version
# 或
python3 --version
```

### 1.2 进入项目目录

Windows PowerShell：

```powershell
cd network_course_design
```

Linux/macOS：

```bash
cd network_course_design
```

### 1.3 权限说明

课题 1 Ping 和课题 3 截包使用 RAW socket，通常需要管理员权限：

- Windows：右键“以管理员身份运行”PowerShell / CMD。
- Linux/macOS：使用 `sudo`。
- 如果提示 `PermissionError`，基本就是权限不足。

---

# 课题 1：Ping 程序设计

## 1.1 设计目标

实现一个基于 ICMP 的 Ping 程序：

1. 不加 `-t`：发送 4 次 ICMP Echo Request。
2. 加 `-t`：无限次 ping，直到按 `Ctrl+C` 停止。
3. 不调用系统自带 `ping` 命令，而是使用 RAW socket 构造 ICMP 报文。

## 1.2 基本原理

Ping 使用 ICMP 协议：

1. 发送方构造 ICMP Echo Request，Type=8，Code=0。
2. IP 层将 ICMP 报文封装到 IP 数据报中发送。
3. 目标主机收到后返回 ICMP Echo Reply，Type=0，Code=0。
4. 本程序检查 Identifier、Sequence，确认回复是否对应本次请求。
5. 用“收到时间 - 发送时间”计算 RTT。

关键字段：

| 字段 | 含义 |
|---|---|
| Type | ICMP 类型，8 表示请求，0 表示应答 |
| Code | 类型下的细分代码，Echo 一般为 0 |
| Checksum | ICMP 校验和，用于检查报文错误 |
| Identifier | 标识本进程发送的 Ping |
| Sequence | 第几次 Ping |

## 1.3 运行方法

进入目录：

```bash
cd topic1_ping
```

普通 4 次 Ping：

```bash
python my_ping.py 8.8.8.8
```

无限 Ping：

```bash
python my_ping.py -t 8.8.8.8
```

设置超时时间为 2 秒：

```bash
python my_ping.py --timeout 2 8.8.8.8
```

Linux 需要：

```bash
sudo python3 my_ping.py 8.8.8.8
```

## 1.4 正常输出示例

```text
PING 8.8.8.8 [8.8.8.8] 4 次。
REPLY FROM 8.8.8.8: bytes=56 time=23.15ms TTL=118
REPLY FROM 8.8.8.8: bytes=56 time=22.87ms TTL=118
REPLY FROM 8.8.8.8: bytes=56 time=24.02ms TTL=118
REPLY FROM 8.8.8.8: bytes=56 time=23.66ms TTL=118
```

如果不通：

```text
REQUEST TimeOut
```

## 1.5 代码讲解重点

### `checksum(data)`

ICMP 报文必须有校验和。程序把数据按 16 位分组求和，然后取反，得到 16 位反码和。

### `build_packet(identifier, sequence)`

构造 ICMP 头部和数据部分。第一次打包时校验和填 0，算出校验和后重新打包。

### `parse_reply(packet, identifier, sequence)`

收到的是 IP 数据报，需要先解析 IP 头部长度，再定位 ICMP 头部。只有 ICMP Type=0、Identifier 和 Sequence 都匹配，才认为是本次 Ping 的回复。

### `run_ping(host, infinite, timeout)`

控制发送次数：普通模式循环 4 次，`-t` 模式一直循环。

## 1.6 常见问题

| 问题 | 原因 | 解决办法 |
|---|---|---|
| PermissionError | RAW socket 需要管理员权限 | Windows 管理员运行；Linux 使用 sudo |
| REQUEST TimeOut | 目标不通、被防火墙拦截 ICMP、网络不通 | 换 127.0.0.1 或网关测试 |
| 能 ping 127.0.0.1，不能 ping 外网 | 本机 TCP/IP 正常，但网关、DNS、路由或防火墙可能有问题 | 检查网关、IP 配置、路由表 |

---

# 课题 2：FTP 客户端与服务器

## 2.1 设计目标

实现一个简单文件传输协议：

1. 服务器端：`ftp_server.py`
2. 客户端：`ftp_client.py`
3. 使用原始 TCP socket，不使用 `ftplib` 等 FTP 高级组件。
4. 支持命令：`get`、`put`、`pwd`、`dir`、`cd`、`?`、`quit`。
5. 文件以二进制方式传输，所以图片可以上传和下载。
6. 服务器端最多允许 3 个客户端同时连接。

## 2.2 协议设计

本项目没有直接实现标准 FTP 的控制连接 + 数据连接双连接结构，而是设计了一个“简化 FTP 协议”，所有命令和文件数据都走同一个 TCP 连接。

### 客户端发送命令

```text
PWD\n
DIR\n
CD 目录名\n
GET 文件名\n
PUT 文件名 文件大小\n
QUIT\n
```

### 服务器响应格式

```text
OK TEXT 文本内容\n
OK DATA 数据长度\n
后面紧跟指定长度的目录列表字节

OK FILE 文件长度 文件名\n
后面紧跟指定长度的文件二进制内容

ERR 错误原因\n
```

为什么要带“长度”？因为图片、压缩包等二进制文件内部可能包含任意字节，不能靠换行判断结束。先告诉对方文件大小，对方就能准确读取对应字节数。

## 2.3 网络拓扑

```mermaid
flowchart LR
    C[FTP Client<br/>ftp_client.py] -- TCP Socket<br/>命令和文件数据 --> S[FTP Server<br/>ftp_server.py]
    S --> R[服务器根目录<br/>ftp_root]
```

## 2.4 运行服务器

进入目录：

```bash
cd topic2_ftp
```

启动服务器：

```bash
python ftp_server.py --host 0.0.0.0 --port 2121 --root ftp_root
```

参数解释：

| 参数 | 含义 |
|---|---|
| `--host 0.0.0.0` | 监听所有网卡，局域网其他电脑也能连接 |
| `--port 2121` | 服务器端口，可按学号后三位 + 2000 修改 |
| `--root ftp_root` | 服务器文件根目录，客户端只能访问此目录内部 |

如果只是本机测试，也可以：

```bash
python ftp_server.py --host 127.0.0.1 --port 2121 --root ftp_root
```

## 2.5 运行客户端

另开一个终端：

```bash
cd topic2_ftp
python ftp_client.py 127.0.0.1 --port 2121
```

连接成功后会进入：

```text
ftp>
```

## 2.6 命令演示

查看帮助：

```text
ftp> ?
```

查看远程目录：

```text
ftp> pwd
```

列出远程文件：

```text
ftp> dir
```

切换目录：

```text
ftp> cd images
```

上传图片：

```text
ftp> put local_photo.jpg
```

上传图片并改名：

```text
ftp> put local_photo.jpg server_photo.jpg
```

下载图片：

```text
ftp> get server_photo.jpg
```

下载图片并改名：

```text
ftp> get server_photo.jpg download_photo.jpg
```

退出：

```text
ftp> quit
```

## 2.7 图片上传下载测试步骤

1. 在 `topic2_ftp` 目录放一张图片，例如 `test.jpg`。
2. 启动服务器：

```bash
python ftp_server.py --host 127.0.0.1 --port 2121 --root ftp_root
```

3. 启动客户端：

```bash
python ftp_client.py 127.0.0.1 --port 2121
```

4. 上传：

```text
ftp> put test.jpg
```

5. 到 `ftp_root` 中检查是否出现 `test.jpg`。
6. 下载并改名：

```text
ftp> get test.jpg test_download.jpg
```

7. 打开 `test_download.jpg`，如果图片能正常显示，说明二进制传输成功。

## 2.8 代码讲解重点

### `recv_line()` 和 `send_line()`

用于传输命令和响应头。命令是文本，以换行作为结束标志。

### `recv_exact(sock, size)`

用于传输二进制文件。它会一直读，直到读满指定字节数，防止 TCP 粘包、拆包造成文件不完整。

### `safe_path()`

服务器端限制客户端不能访问 `ftp_root` 之外的目录，避免用户输入 `../../` 读写系统文件。

### 多客户端限制

服务器使用线程处理客户端，同时用 `threading.Semaphore(3)` 限制并发数不超过 3。

## 2.9 常见问题

| 问题 | 原因 | 解决办法 |
|---|---|---|
| 连接被拒绝 | 服务器没启动或端口不一致 | 先启动 server，确认端口一致 |
| 局域网其他电脑连不上 | 服务器只监听 127.0.0.1 或防火墙阻止 | 用 `--host 0.0.0.0`，允许端口通过防火墙 |
| 图片打不开 | 没有按二进制完整收发 | 本项目使用 `rb/wb` 和长度字段，正常不会损坏 |
| 端口占用 | 2121 被其他程序使用 | 换成 2000~5000 中未占用端口 |

---

# 课题 3：局域网截包程序设计

## 3.1 设计目标

截获并解析：

1. 数据链路层：以太网帧目的 MAC、源 MAC、类型字段。
2. 网络层：IPv4 版本、头部长度、总长度、TTL、协议号、源 IP、目的 IP。
3. 运输层：ICMP、TCP、UDP 的基本字段。

## 3.2 运行方法

Linux 推荐，因为可以直接用 `AF_PACKET` 获取以太网帧：

```bash
cd topic3_sniffer
sudo python3 lan_sniffer.py --interface eth0 --count 10
```

不知道网卡名时：

```bash
ip addr
```

常见网卡名：`eth0`、`ens33`、`wlan0`。

不指定网卡：

```bash
sudo python3 lan_sniffer.py --count 10
```

Windows 管理员模式：

```powershell
python lan_sniffer.py --host 本机IP --count 10
```

Windows 标准 RAW IP socket 通常只能看到 IP 层及以上；如果答辩要求完整以太网帧，建议在 Linux 虚拟机中演示。

## 3.3 输出示例

```text
[1] 捕获数据帧
Ethernet: 00:11:22:33:44:55 -> aa:bb:cc:dd:ee:ff, type=0x0800, frame_len=74
  IPv4: version=4, header=20B, total=60, ttl=64, proto=6, 192.168.1.10 -> 192.168.1.1, flags=2, frag_offset=0
    TCP: 52344 -> 80, seq=123456, ack=0, header=40B, flags=SYN, window=64240
```

## 3.4 协议字段讲解

### 以太网帧

| 字段 | 长度 | 含义 |
|---|---:|---|
| 目的 MAC | 6 字节 | 接收方网卡地址 |
| 源 MAC | 6 字节 | 发送方网卡地址 |
| 类型 Type | 2 字节 | `0x0800` 表示 IPv4，`0x0806` 表示 ARP |
| 数据 | 可变 | 上层协议数据 |

### IPv4

| 字段 | 含义 |
|---|---|
| Version | IP 版本，IPv4 为 4 |
| IHL | IP 头长度 |
| Total Length | IP 数据报总长度 |
| TTL | 生存时间，每经过一个路由器减 1 |
| Protocol | 上层协议，1=ICMP，6=TCP，17=UDP |
| Source/Destination | 源 IP / 目的 IP |

### TCP / UDP / ICMP

- TCP：面向连接，包含端口、序号、确认号、窗口、标志位。
- UDP：无连接，包含源端口、目的端口、长度。
- ICMP：用于差错报告和网络测试，Ping 就使用 ICMP Echo。

## 3.5 安全与边界

本程序默认不打印应用层载荷，只解析头部字段。答辩时可以说明：课程设计目的是理解封装和解封装机制，不用于获取隐私数据。

---

# 课题 4：数据链路层协议设计与实现

## 4.1 设计目标

实现三种 ARQ 协议模拟：

1. 停止-等待协议 Stop-and-Wait。
2. 回退 N 帧协议 Go-Back-N。
3. 选择重发协议 Selective Repeat。

其中“停止-等待、回退 N 帧”覆盖课程要求；“选择重发”用于覆盖指导书中的扩展要求。

## 4.2 运行方法

进入目录：

```bash
cd topic4_datalink
```

全部演示：

```bash
python datalink_protocols.py --protocol all
```

只演示停止-等待：

```bash
python datalink_protocols.py --protocol sw --frames 5
```

只演示回退 N：

```bash
python datalink_protocols.py --protocol gbn --frames 8 --window 4
```

只演示选择重发：

```bash
python datalink_protocols.py --protocol sr --frames 8 --window 4
```

调整丢帧率和 ACK 丢失率：

```bash
python datalink_protocols.py --protocol all --loss 0.3 --ack-loss 0.2 --seed 2026
```

## 4.3 输出怎么看

### 停止-等待

特点：发送方一次只发一帧，收到 ACK 后再发下一帧。

优点：实现简单。

缺点：信道利用率低。

### 回退 N 帧

特点：发送方可以连续发送窗口内的多个帧；接收方只接收按序到达的帧。如果某一帧丢失，后面帧即使到了也会被丢弃，发送方超时后从丢失帧开始重传整个窗口。

优点：比停止-等待效率高。

缺点：信道错误率高时会重复发送很多已经到达过的帧。

### 选择重发

特点：接收方可以缓存乱序帧，对每个帧单独确认，发送方只重传丢失或未确认的帧。

优点：减少不必要重传。

缺点：实现复杂，需要接收缓存和更复杂的序号管理。

## 4.4 三种协议对比

| 协议 | 发送窗口 | 接收窗口 | 是否缓存乱序帧 | 重传方式 | 复杂度 |
|---|---:|---:|---|---|---|
| 停止-等待 | 1 | 1 | 否 | 一帧一帧重传 | 低 |
| 回退 N | N | 1 | 否 | 从出错帧开始重传整个窗口 | 中 |
| 选择重发 | N | N | 是 | 只重传出错帧 | 高 |

---

# 5. 报告写作建议

课程报告不要直接复制大量代码。建议这样写：

1. 设计任务：说明完成了四个课题。
2. 基本思想：按课题说明 ICMP、TCP socket、自定义 FTP、以太网/IP/TCP/UDP 解码、ARQ。
3. 方案设计：放 C/S 拓扑图、协议流程图、数据链路层窗口示意图。
4. 具体配置步骤：写运行命令、端口、管理员权限、测试 IP。
5. 结果及分析：粘贴少量运行截图，并解释输出字段。
6. 调试问题：写权限不足、端口占用、防火墙、图片损坏、截不到包等问题和解决办法。
7. 思考题：参考 `docs/课程设计报告模板.md`。
8. 个人体会：写自己对分层协议、socket 编程、二进制传输、差错控制的理解。

## 5.1 推荐截图

| 课题 | 推荐截图 |
|---|---|
| Ping | 普通 4 次 ping；`-t` 后 Ctrl+C 停止；超时情况可选 |
| FTP | server 启动；client 的 pwd/dir/cd；put 图片；get 图片；图片能打开 |
| 截包 | 捕获 Ethernet + IPv4 + TCP/UDP/ICMP 字段 |
| 数据链路层 | 停止-等待重传；回退 N 窗口滑动；选择重发缓存乱序帧 |

