#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
课题3：局域网截包程序设计（教学版）
功能：
- Linux：使用 AF_PACKET 原始套接字截获以太网帧，解析数据链路层、网络层、运输层字段。
- Windows：使用 RAW IP socket + SIO_RCVALL 截获 IP 包，能解析网络层和运输层；若要完整以太网帧，通常需要 Npcap/WinPcap。
安全说明：仅在自己拥有或被授权的实验网络中运行；默认不打印应用层载荷，避免泄露隐私。
"""

from __future__ import annotations

import argparse
import socket
import struct
import sys
from typing import Optional

ETH_P_ALL = 0x0003


def mac_addr(raw: bytes) -> str:
    return ":".join(f"{b:02x}" for b in raw)


def ipv4_addr(raw: bytes) -> str:
    return socket.inet_ntoa(raw)


def parse_tcp(segment: bytes) -> str:
    if len(segment) < 20:
        return "TCP: 长度不足"
    src_port, dst_port, seq, ack, offset_flags, window, checksum, urgent = struct.unpack("!HHIIHHHH", segment[:20])
    data_offset = ((offset_flags >> 12) & 0xF) * 4
    flags = offset_flags & 0x01FF
    flag_names = []
    for bit, name in [(0x100, "NS"), (0x080, "CWR"), (0x040, "ECE"), (0x020, "URG"), (0x010, "ACK"), (0x008, "PSH"), (0x004, "RST"), (0x002, "SYN"), (0x001, "FIN")]:
        if flags & bit:
            flag_names.append(name)
    return f"TCP: {src_port} -> {dst_port}, seq={seq}, ack={ack}, header={data_offset}B, flags={','.join(flag_names) or '-'}, window={window}"


def parse_udp(segment: bytes) -> str:
    if len(segment) < 8:
        return "UDP: 长度不足"
    src_port, dst_port, length, checksum = struct.unpack("!HHHH", segment[:8])
    return f"UDP: {src_port} -> {dst_port}, length={length}"


def parse_icmp(data: bytes) -> str:
    if len(data) < 4:
        return "ICMP: 长度不足"
    icmp_type, code, checksum = struct.unpack("!BBH", data[:4])
    return f"ICMP: type={icmp_type}, code={code}, checksum=0x{checksum:04x}"


def parse_ipv4(packet: bytes, prefix: str = "") -> None:
    if len(packet) < 20:
        print(prefix + "IPv4: 长度不足")
        return
    first, tos, total_len, ident, flags_frag, ttl, proto, checksum, src, dst = struct.unpack("!BBHHHBBH4s4s", packet[:20])
    version = first >> 4
    ihl = (first & 0x0F) * 4
    flags = flags_frag >> 13
    frag_offset = flags_frag & 0x1FFF
    src_ip = ipv4_addr(src)
    dst_ip = ipv4_addr(dst)
    print(prefix + f"IPv4: version={version}, header={ihl}B, total={total_len}, ttl={ttl}, proto={proto}, {src_ip} -> {dst_ip}, flags={flags}, frag_offset={frag_offset}")
    payload = packet[ihl:total_len] if total_len <= len(packet) else packet[ihl:]
    if proto == 1:
        print(prefix + "  " + parse_icmp(payload))
    elif proto == 6:
        print(prefix + "  " + parse_tcp(payload))
    elif proto == 17:
        print(prefix + "  " + parse_udp(payload))
    else:
        print(prefix + f"  Transport: 暂未解析的协议号 {proto}")


def parse_ethernet(frame: bytes) -> None:
    if len(frame) < 14:
        print("Ethernet: 长度不足")
        return
    dst, src, proto = struct.unpack("!6s6sH", frame[:14])
    print(f"Ethernet: {mac_addr(src)} -> {mac_addr(dst)}, type=0x{proto:04x}, frame_len={len(frame)}")
    if proto == 0x0800:
        parse_ipv4(frame[14:], "  ")
    elif proto == 0x0806:
        print("  ARP: 本程序只显示 ARP 类型，不展开字段")
    elif proto == 0x86DD:
        print("  IPv6: 本程序重点解析 IPv4，IPv6 可作为扩展")
    else:
        print("  未解析的数据链路层协议类型")


def sniff_linux(interface: Optional[str], count: int) -> None:
    sock = socket.socket(socket.AF_PACKET, socket.SOCK_RAW, socket.ntohs(ETH_P_ALL))
    if interface:
        sock.bind((interface, 0))
    print("开始截包：Ctrl+C 停止。")
    i = 0
    while count <= 0 or i < count:
        frame, _ = sock.recvfrom(65535)
        i += 1
        print(f"\n[{i}] 捕获数据帧")
        parse_ethernet(frame)


def sniff_windows(host: str, count: int) -> None:
    sock = socket.socket(socket.AF_INET, socket.SOCK_RAW, socket.IPPROTO_IP)
    sock.bind((host, 0))
    sock.setsockopt(socket.IPPROTO_IP, socket.IP_HDRINCL, 1)
    # SIO_RCVALL = 0x98000001，开启混杂接收 IP 包
    sock.ioctl(0x98000001, struct.pack("I", 1))
    print("Windows RAW IP 模式开始截包：只能看到 IP 层及以上，Ctrl+C 停止。")
    i = 0
    try:
        while count <= 0 or i < count:
            packet, _ = sock.recvfrom(65535)
            i += 1
            print(f"\n[{i}] 捕获 IP 包")
            parse_ipv4(packet, "  ")
    finally:
        sock.ioctl(0x98000001, struct.pack("I", 0))
        sock.close()


def main() -> None:
    parser = argparse.ArgumentParser(description="课程设计课题3：局域网截包程序")
    parser.add_argument("--interface", help="Linux 网卡名，例如 eth0、wlan0；不填则监听默认接口")
    parser.add_argument("--host", default="127.0.0.1", help="Windows 本机 IP，用于 RAW IP 绑定")
    parser.add_argument("--count", type=int, default=10, help="截获数量，0 表示一直截获，默认 10")
    args = parser.parse_args()

    try:
        if sys.platform.startswith("linux"):
            sniff_linux(args.interface, args.count)
        elif sys.platform.startswith("win"):
            sniff_windows(args.host, args.count)
        else:
            print("当前系统可能不支持本示例的 RAW socket 截包。建议在 Linux 或 Windows 管理员模式下运行。")
    except PermissionError:
        print("权限不足：请使用 root/管理员权限运行。")
    except KeyboardInterrupt:
        print("\n用户停止截包。")


if __name__ == "__main__":
    main()
