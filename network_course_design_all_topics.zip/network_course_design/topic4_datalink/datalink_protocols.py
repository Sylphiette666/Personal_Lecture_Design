#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
课题4：数据链路层协议模拟
实现：
1. 停止-等待协议 Stop-and-Wait
2. 回退 N 帧协议 Go-Back-N
3. 选择重发协议 Selective Repeat（指导书中出现，额外实现）

程序通过随机丢帧、丢 ACK 模拟不可靠链路，观察 ARQ 重传过程。
"""

from __future__ import annotations

import argparse
import random
from dataclasses import dataclass
from typing import List, Set


@dataclass
class Channel:
    loss_rate: float
    ack_loss_rate: float
    seed: int

    def __post_init__(self) -> None:
        self.rng = random.Random(self.seed)

    def frame_ok(self) -> bool:
        return self.rng.random() >= self.loss_rate

    def ack_ok(self) -> bool:
        return self.rng.random() >= self.ack_loss_rate


def stop_and_wait(total_frames: int, channel: Channel) -> List[str]:
    logs: List[str] = []
    seq = 0
    for frame in range(total_frames):
        attempt = 1
        while True:
            logs.append(f"发送方：发送帧 frame={frame}, seq={seq}, 第 {attempt} 次")
            if not channel.frame_ok():
                logs.append("信道：数据帧丢失，接收方没有收到，发送方等待超时")
                attempt += 1
                continue
            logs.append(f"接收方：收到 frame={frame}, seq={seq}，向发送方回 ACK{seq}")
            if not channel.ack_ok():
                logs.append(f"信道：ACK{seq} 丢失，发送方超时后重传同一帧")
                attempt += 1
                continue
            logs.append(f"发送方：收到 ACK{seq}，frame={frame} 发送成功\n")
            seq ^= 1
            break
    logs.append("停止-等待协议结束：所有帧发送完毕。")
    return logs


def go_back_n(total_frames: int, window_size: int, channel: Channel) -> List[str]:
    logs: List[str] = []
    base = 0
    expected = 0
    round_no = 1

    while base < total_frames:
        end = min(base + window_size, total_frames)
        logs.append(f"\n第 {round_no} 轮：发送窗口=[{base}, {end - 1}]，接收方期望帧={expected}")
        largest_ack = base

        for frame in range(base, end):
            seq = frame % (window_size + 1)
            logs.append(f"发送方：发送 frame={frame}, seq={seq}")
            if not channel.frame_ok():
                logs.append(f"信道：frame={frame} 丢失")
                continue

            if frame == expected:
                expected += 1
                logs.append(f"接收方：按序收到 frame={frame}，累计确认 ACK{expected}")
            else:
                logs.append(f"接收方：收到 frame={frame}，但期望 frame={expected}，丢弃并重复 ACK{expected}")

            if channel.ack_ok():
                largest_ack = max(largest_ack, expected)
                logs.append(f"发送方：收到累计 ACK{expected}")
            else:
                logs.append(f"信道：ACK{expected} 丢失")

        if largest_ack > base:
            logs.append(f"窗口滑动：base 从 {base} 移动到 {largest_ack}")
            base = largest_ack
        else:
            logs.append(f"超时：没有收到新的累计 ACK，回退到 base={base} 重新发送整个窗口")
        round_no += 1

    logs.append("\n回退 N 帧协议结束：所有帧按序接收。")
    return logs


def selective_repeat(total_frames: int, window_size: int, channel: Channel) -> List[str]:
    logs: List[str] = []
    base = 0
    acked: Set[int] = set()
    received_buffer: Set[int] = set()
    deliver_next = 0
    round_no = 1

    while base < total_frames:
        end = min(base + window_size, total_frames)
        logs.append(f"\n第 {round_no} 轮：发送窗口=[{base}, {end - 1}]，已确认={sorted(acked)}")

        for frame in range(base, end):
            if frame in acked:
                continue
            seq = frame % (2 * window_size)
            logs.append(f"发送方：发送/重传 frame={frame}, seq={seq}")
            if not channel.frame_ok():
                logs.append(f"信道：frame={frame} 丢失")
                continue

            received_buffer.add(frame)
            logs.append(f"接收方：收到 frame={frame}，缓存并单独确认 ACK{frame}")
            if channel.ack_ok():
                acked.add(frame)
                logs.append(f"发送方：收到 ACK{frame}，标记 frame={frame} 已确认")
            else:
                logs.append(f"信道：ACK{frame} 丢失，发送方之后会单独重传该帧")

        while deliver_next in received_buffer:
            logs.append(f"接收方：向上层交付 frame={deliver_next}")
            deliver_next += 1

        old_base = base
        while base in acked:
            base += 1
        if base != old_base:
            logs.append(f"窗口滑动：base 从 {old_base} 移动到 {base}")
        else:
            logs.append(f"窗口暂不滑动：base={base} 尚未确认，等待超时后只重传未确认帧")
        round_no += 1

    logs.append("\n选择重发协议结束：所有帧已确认并交付。")
    return logs


def main() -> None:
    parser = argparse.ArgumentParser(description="课程设计课题4：数据链路层 ARQ 协议模拟")
    parser.add_argument("--protocol", choices=["sw", "gbn", "sr", "all"], default="all", help="sw=停止等待, gbn=回退N, sr=选择重发, all=全部演示")
    parser.add_argument("--frames", type=int, default=8, help="帧总数，默认 8")
    parser.add_argument("--window", type=int, default=4, help="窗口大小，默认 4")
    parser.add_argument("--loss", type=float, default=0.25, help="数据帧丢失率，默认 0.25")
    parser.add_argument("--ack-loss", type=float, default=0.15, help="ACK 丢失率，默认 0.15")
    parser.add_argument("--seed", type=int, default=2026, help="随机种子，默认 2026，便于复现实验结果")
    args = parser.parse_args()

    protocols = [args.protocol] if args.protocol != "all" else ["sw", "gbn", "sr"]
    for p in protocols:
        print("=" * 70)
        if p == "sw":
            print("停止-等待协议 Stop-and-Wait")
            logs = stop_and_wait(args.frames, Channel(args.loss, args.ack_loss, args.seed))
        elif p == "gbn":
            print("回退 N 帧协议 Go-Back-N")
            logs = go_back_n(args.frames, args.window, Channel(args.loss, args.ack_loss, args.seed))
        else:
            print("选择重发协议 Selective Repeat")
            logs = selective_repeat(args.frames, args.window, Channel(args.loss, args.ack_loss, args.seed))
        print("\n".join(logs))


if __name__ == "__main__":
    main()
