#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
课题1：Ping 程序设计
功能：
1. python my_ping.py 目标IP        -> 默认发送 4 次 ICMP Echo Request
2. python my_ping.py -t 目标IP     -> 一直 ping，直到 Ctrl+C
说明：
- 使用原始套接字 socket.SOCK_RAW 直接构造 ICMP 报文，没有调用系统 ping 命令。
- Windows / Linux / macOS 通常都需要管理员权限或 root 权限运行。
"""

from __future__ import annotations

import argparse
import os
import select
import socket
import struct
import sys
import time
from typing import Optional, Tuple

ICMP_ECHO_REQUEST = 8
ICMP_ECHO_REPLY = 0
DEFAULT_TIMEOUT = 1.0
DEFAULT_PAYLOAD_SIZE = 56


def checksum(data: bytes) -> int:
    """计算 ICMP 校验和：16 位反码和。"""
    if len(data) % 2:
        data += b"\x00"

    total = 0
    for i in range(0, len(data), 2):
        word = data[i] + (data[i + 1] << 8)
        total += word
        total = (total & 0xFFFF) + (total >> 16)

    total = ~total & 0xFFFF
    # 网络字节序为大端；这里转成 ICMP 头部需要的格式
    return socket.htons(total)


def build_packet(identifier: int, sequence: int, payload_size: int = DEFAULT_PAYLOAD_SIZE) -> bytes:
    """构造一个 ICMP Echo Request 报文。"""
    # ICMP 头部格式：Type(1) Code(1) Checksum(2) Identifier(2) Sequence(2)
    header = struct.pack("!BBHHH", ICMP_ECHO_REQUEST, 0, 0, identifier, sequence)
    # payload 中放入发送时间，便于观察；不足部分用固定字符填充
    timestamp = struct.pack("!d", time.time())
    padding = bytes((65 + sequence % 26 for _ in range(max(0, payload_size - len(timestamp)))))
    payload = timestamp + padding
    packet_checksum = checksum(header + payload)
    header = struct.pack("!BBHHH", ICMP_ECHO_REQUEST, 0, packet_checksum, identifier, sequence)
    return header + payload


def parse_reply(packet: bytes, identifier: int, sequence: int) -> Optional[Tuple[str, int, int]]:
    """
    解析收到的 IP 数据报，检查是否为本程序发出的 ICMP Echo Reply。
    返回：(源IP, TTL, 数据字节数)，不匹配则返回 None。
    """
    if len(packet) < 20:
        return None

    # IP 头第一个字节低 4 位表示 IP 头长度，单位为 4 字节
    first_byte = packet[0]
    ip_header_length = (first_byte & 0x0F) * 4
    if len(packet) < ip_header_length + 8:
        return None

    ip_header = packet[:ip_header_length]
    ttl = ip_header[8]
    source_ip = socket.inet_ntoa(ip_header[12:16])

    icmp_header = packet[ip_header_length:ip_header_length + 8]
    icmp_type, icmp_code, recv_checksum, recv_id, recv_seq = struct.unpack("!BBHHH", icmp_header)

    if icmp_type == ICMP_ECHO_REPLY and icmp_code == 0 and recv_id == identifier and recv_seq == sequence:
        data_len = len(packet) - ip_header_length - 8
        return source_ip, ttl, data_len
    return None


def ping_once(sock: socket.socket, destination_ip: str, sequence: int, timeout: float) -> None:
    """发送一次 ICMP Echo Request，并等待对应的 Echo Reply。"""
    identifier = os.getpid() & 0xFFFF
    packet = build_packet(identifier, sequence)
    start_time = time.time()
    sock.sendto(packet, (destination_ip, 0))

    remaining = timeout
    while remaining > 0:
        ready, _, _ = select.select([sock], [], [], remaining)
        if not ready:
            break
        received_time = time.time()
        recv_packet, _ = sock.recvfrom(65535)
        parsed = parse_reply(recv_packet, identifier, sequence)
        if parsed:
            source_ip, ttl, data_len = parsed
            rtt_ms = (received_time - start_time) * 1000
            print(f"REPLY FROM {source_ip}: bytes={data_len} time={rtt_ms:.2f}ms TTL={ttl}")
            return
        remaining = timeout - (time.time() - start_time)

    print("REQUEST TimeOut")


def run_ping(host: str, infinite: bool, timeout: float) -> None:
    """主流程：解析目标 IP，创建 RAW socket，然后循环发送。"""
    try:
        destination_ip = socket.gethostbyname(host)
    except socket.gaierror:
        print(f"无法解析目标地址：{host}")
        sys.exit(2)

    print(f"PING {host} [{destination_ip}]，按 Ctrl+C 停止。" if infinite else f"PING {host} [{destination_ip}] 4 次。")

    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_RAW, socket.IPPROTO_ICMP)
    except PermissionError:
        print("创建 RAW socket 失败：请用管理员权限/root 运行本程序。")
        sys.exit(1)
    except OSError as exc:
        print(f"创建 RAW socket 失败：{exc}")
        sys.exit(1)

    sequence = 1
    sent = received = 0
    try:
        while infinite or sequence <= 4:
            sent += 1
            before = time.time()
            # 为了统计成功次数，临时捕获输出不方便；这里用独立函数完成显示，统计只给发送数
            ping_once(sock, destination_ip, sequence, timeout)
            # 简单间隔 1 秒，模仿系统 ping
            elapsed = time.time() - before
            time.sleep(max(0.0, 1.0 - elapsed))
            sequence += 1
    except KeyboardInterrupt:
        print("\n用户停止 ping。")
    finally:
        sock.close()
        print(f"\n发送数据包：{sent} 个。接收成功数量请以上方 REPLY 行为准。")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="课程设计课题1：使用 RAW socket 实现 Ping")
    parser.add_argument("args", nargs="+", help="用法：python my_ping.py [-t] 目标IP")
    parser.add_argument("--timeout", type=float, default=DEFAULT_TIMEOUT, help="等待超时时间，默认 1 秒")
    return parser.parse_args()


def main() -> None:
    ns = parse_args()
    infinite = False
    items = ns.args[:]
    if "-t" in items:
        infinite = True
        items.remove("-t")
    if len(items) != 1:
        print("用法：python my_ping.py 目标IP 或 python my_ping.py -t 目标IP")
        sys.exit(2)
    run_ping(items[0], infinite, ns.timeout)


if __name__ == "__main__":
    main()
