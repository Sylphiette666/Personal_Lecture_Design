#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
课题2：FTP 客户端（简化版文件传输协议）
支持命令：get、put、pwd、dir、cd、?、quit。
使用标准库 socket，不使用高级 FTP 组件。
"""

from __future__ import annotations

import argparse
import os
import shlex
import socket
from pathlib import Path

CHUNK_SIZE = 64 * 1024


def recv_line(sock: socket.socket) -> str:
    data = bytearray()
    while True:
        ch = sock.recv(1)
        if not ch:
            raise ConnectionError("服务器断开连接")
        if ch == b"\n":
            break
        data.extend(ch)
    return data.decode("utf-8", errors="replace").rstrip("\r")


def send_line(sock: socket.socket, line: str) -> None:
    sock.sendall((line + "\n").encode("utf-8"))


def recv_exact(sock: socket.socket, size: int) -> bytes:
    buf = bytearray()
    while len(buf) < size:
        chunk = sock.recv(min(CHUNK_SIZE, size - len(buf)))
        if not chunk:
            raise ConnectionError("传输过程中连接断开")
        buf.extend(chunk)
    return bytes(buf)


def print_response(sock: socket.socket) -> bool:
    """打印普通命令响应。返回 False 表示出错。"""
    line = recv_line(sock)
    if line.startswith("OK TEXT "):
        print(line[len("OK TEXT "):])
        return True
    if line.startswith("OK DATA "):
        size = int(line.split()[2])
        data = recv_exact(sock, size)
        print(data.decode("utf-8", errors="replace"))
        return True
    if line.startswith("ERR "):
        print("错误：" + line[4:])
        return False
    print("服务器返回未知格式：" + line)
    return False


def do_put(sock: socket.socket, local_file: str, remote_file: str | None = None) -> None:
    path = Path(local_file)
    if not path.exists() or not path.is_file():
        print("本地文件不存在")
        return
    remote = remote_file or path.name
    size = path.stat().st_size
    send_line(sock, f"PUT {shlex.quote(remote)} {size}")
    with path.open("rb") as f:
        while True:
            chunk = f.read(CHUNK_SIZE)
            if not chunk:
                break
            sock.sendall(chunk)
    print_response(sock)


def do_get(sock: socket.socket, remote_file: str, local_file: str | None = None) -> None:
    send_line(sock, f"GET {shlex.quote(remote_file)}")
    line = recv_line(sock)
    if line.startswith("ERR "):
        print("错误：" + line[4:])
        return
    if not line.startswith("OK FILE "):
        print("服务器返回未知格式：" + line)
        return
    parts = line.split(maxsplit=3)
    size = int(parts[2])
    filename_from_server = parts[3] if len(parts) > 3 else Path(remote_file).name
    local = Path(local_file or filename_from_server)
    with local.open("wb") as f:
        remaining = size
        while remaining:
            chunk = sock.recv(min(CHUNK_SIZE, remaining))
            if not chunk:
                raise ConnectionError("下载过程中连接断开")
            f.write(chunk)
            remaining -= len(chunk)
    print(f"下载完成：{local}，大小 {size} 字节")


def repl(sock: socket.socket) -> None:
    print_response(sock)  # welcome
    while True:
        try:
            line = input("ftp> ").strip()
        except EOFError:
            line = "quit"
        if not line:
            continue
        try:
            parts = shlex.split(line)
        except ValueError as exc:
            print(f"命令解析错误：{exc}")
            continue
        cmd = parts[0].lower()
        try:
            if cmd in {"?", "help"}:
                send_line(sock, "?")
                print_response(sock)
            elif cmd == "put":
                if len(parts) < 2:
                    print("用法：put 本地文件 [远程文件名]")
                else:
                    do_put(sock, parts[1], parts[2] if len(parts) >= 3 else None)
            elif cmd == "get":
                if len(parts) < 2:
                    print("用法：get 远程文件 [本地文件名]")
                else:
                    do_get(sock, parts[1], parts[2] if len(parts) >= 3 else None)
            elif cmd in {"pwd", "dir"}:
                send_line(sock, cmd.upper())
                print_response(sock)
            elif cmd == "cd":
                if len(parts) < 2:
                    print("用法：cd 远程目录")
                else:
                    send_line(sock, f"CD {shlex.quote(parts[1])}")
                    print_response(sock)
            elif cmd == "quit":
                send_line(sock, "QUIT")
                print_response(sock)
                break
            else:
                print("未知命令，输入 ? 查看帮助")
        except ConnectionError as exc:
            print(f"连接错误：{exc}")
            break


def main() -> None:
    parser = argparse.ArgumentParser(description="课程设计课题2：简化 FTP 客户端")
    parser.add_argument("host", help="服务器 IP，例如 127.0.0.1")
    parser.add_argument("--port", type=int, default=2121, help="服务器端口，默认 2121")
    args = parser.parse_args()

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.connect((args.host, args.port))
        repl(sock)


if __name__ == "__main__":
    main()
