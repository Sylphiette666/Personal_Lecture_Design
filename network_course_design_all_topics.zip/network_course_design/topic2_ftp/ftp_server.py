#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
课题2：FTP 服务器端（简化版文件传输协议）
特点：
- 只使用 Python 标准库 socket，不使用 ftplib 等 FTP 组件。
- 控制命令和文件内容都通过同一个 TCP 连接传输。
- 支持：get、put、pwd、dir、cd、?、quit。
- 文件按二进制读写，因此 jpg/png/gif 等图片可以上传和下载。
"""

from __future__ import annotations

import argparse
import os
import shlex
import socket
import threading
from pathlib import Path
from typing import Tuple

CHUNK_SIZE = 64 * 1024
MAX_CLIENTS = 3


def recv_line(conn: socket.socket) -> str:
    """从 socket 中读取一行 UTF-8 文本，行尾为 \n。"""
    data = bytearray()
    while True:
        ch = conn.recv(1)
        if not ch:
            raise ConnectionError("客户端断开连接")
        if ch == b"\n":
            break
        data.extend(ch)
    return data.decode("utf-8", errors="replace").rstrip("\r")


def send_line(conn: socket.socket, line: str) -> None:
    conn.sendall((line + "\n").encode("utf-8"))


def recv_exact(conn: socket.socket, size: int) -> bytes:
    """准确读取 size 字节，用于接收二进制文件。"""
    buf = bytearray()
    while len(buf) < size:
        chunk = conn.recv(min(CHUNK_SIZE, size - len(buf)))
        if not chunk:
            raise ConnectionError("传输过程中连接断开")
        buf.extend(chunk)
    return bytes(buf)


class FTPClientSession(threading.Thread):
    def __init__(self, conn: socket.socket, addr: Tuple[str, int], root: Path, semaphore: threading.Semaphore):
        super().__init__(daemon=True)
        self.conn = conn
        self.addr = addr
        self.root = root.resolve()
        self.cwd = self.root
        self.semaphore = semaphore

    def safe_path(self, user_path: str) -> Path:
        """把用户输入路径限制在 root 目录内，防止 cd ../../ 访问系统目录。"""
        if not user_path or user_path == ".":
            candidate = self.cwd
        else:
            p = Path(user_path)
            candidate = (self.root / p if p.is_absolute() else self.cwd / p).resolve()
        if self.root != candidate and self.root not in candidate.parents:
            raise ValueError("禁止访问服务器根目录之外的路径")
        return candidate

    def relative_cwd(self) -> str:
        rel = self.cwd.relative_to(self.root)
        return "/" if str(rel) == "." else "/" + str(rel).replace(os.sep, "/")

    def cmd_pwd(self) -> None:
        send_line(self.conn, f"OK TEXT {self.relative_cwd()}")

    def cmd_dir(self) -> None:
        rows = []
        for item in sorted(self.cwd.iterdir(), key=lambda p: (not p.is_dir(), p.name.lower())):
            kind = "<DIR>" if item.is_dir() else "     "
            size = "" if item.is_dir() else str(item.stat().st_size)
            rows.append(f"{kind:5} {size:>10} {item.name}")
        text = "\n".join(rows) if rows else "<empty>"
        data = text.encode("utf-8")
        send_line(self.conn, f"OK DATA {len(data)}")
        self.conn.sendall(data)

    def cmd_cd(self, target: str) -> None:
        path = self.safe_path(target)
        if not path.exists() or not path.is_dir():
            send_line(self.conn, "ERR 目录不存在")
            return
        self.cwd = path
        send_line(self.conn, f"OK TEXT 当前目录：{self.relative_cwd()}")

    def cmd_get(self, filename: str) -> None:
        path = self.safe_path(filename)
        if not path.exists() or not path.is_file():
            send_line(self.conn, "ERR 文件不存在")
            return
        size = path.stat().st_size
        send_line(self.conn, f"OK FILE {size} {path.name}")
        with path.open("rb") as f:
            while True:
                chunk = f.read(CHUNK_SIZE)
                if not chunk:
                    break
                self.conn.sendall(chunk)

    def cmd_put(self, filename: str, size_text: str) -> None:
        try:
            size = int(size_text)
            if size < 0:
                raise ValueError
        except ValueError:
            send_line(self.conn, "ERR 文件大小不合法")
            return
        path = self.safe_path(filename)
        if path.exists() and path.is_dir():
            send_line(self.conn, "ERR 目标是目录，不能覆盖")
            return
        path.parent.mkdir(parents=True, exist_ok=True)
        data = recv_exact(self.conn, size)
        with path.open("wb") as f:
            f.write(data)
        send_line(self.conn, f"OK TEXT 已保存 {path.name}，大小 {size} 字节")

    def cmd_help(self) -> None:
        help_text = "命令：get 文件名 | put 文件名 | pwd | dir | cd 目录 | ? | quit"
        send_line(self.conn, f"OK TEXT {help_text}")

    def run(self) -> None:
        with self.semaphore:
            print(f"[连接] {self.addr}")
            try:
                send_line(self.conn, "OK TEXT 欢迎使用课程设计简化 FTP 服务器，输入 ? 查看命令")
                while True:
                    line = recv_line(self.conn)
                    if not line:
                        continue
                    parts = shlex.split(line)
                    if not parts:
                        continue
                    cmd = parts[0].upper()
                    try:
                        if cmd == "PWD":
                            self.cmd_pwd()
                        elif cmd == "DIR":
                            self.cmd_dir()
                        elif cmd == "CD" and len(parts) >= 2:
                            self.cmd_cd(parts[1])
                        elif cmd == "GET" and len(parts) >= 2:
                            self.cmd_get(parts[1])
                        elif cmd == "PUT" and len(parts) >= 3:
                            self.cmd_put(parts[1], parts[2])
                        elif cmd in {"?", "HELP"}:
                            self.cmd_help()
                        elif cmd == "QUIT":
                            send_line(self.conn, "OK TEXT bye")
                            break
                        else:
                            send_line(self.conn, "ERR 未知命令或参数不足，输入 ? 查看帮助")
                    except ValueError as exc:
                        send_line(self.conn, f"ERR {exc}")
                    except OSError as exc:
                        send_line(self.conn, f"ERR 文件操作失败：{exc}")
            except (ConnectionError, OSError) as exc:
                print(f"[断开] {self.addr}：{exc}")
            finally:
                self.conn.close()


def main() -> None:
    parser = argparse.ArgumentParser(description="课程设计课题2：简化 FTP 服务器")
    parser.add_argument("--host", default="0.0.0.0", help="监听地址，默认 0.0.0.0")
    parser.add_argument("--port", type=int, default=2121, help="监听端口，建议用 2000~5000，默认 2121")
    parser.add_argument("--root", default="ftp_root", help="服务器根目录，默认 ftp_root")
    args = parser.parse_args()

    root = Path(args.root)
    root.mkdir(parents=True, exist_ok=True)
    semaphore = threading.Semaphore(MAX_CLIENTS)

    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind((args.host, args.port))
    server.listen(10)
    print(f"FTP 服务器启动：{args.host}:{args.port}，根目录：{root.resolve()}，最多并发 {MAX_CLIENTS} 个客户端")

    try:
        while True:
            conn, addr = server.accept()
            FTPClientSession(conn, addr, root, semaphore).start()
    except KeyboardInterrupt:
        print("\n服务器已停止")
    finally:
        server.close()


if __name__ == "__main__":
    main()
