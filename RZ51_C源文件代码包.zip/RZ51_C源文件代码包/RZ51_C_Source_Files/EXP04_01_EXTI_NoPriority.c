/*
 * EXP04_01_EXTI_NoPriority.c
 * Function: external interrupt experiment without priority.
 * Requirement:
 *   - P1 connects 8 LEDs.
 *   - INT0/P3.2 uses K1, falling edge trigger.
 *   - INT1/P3.3 uses K2, falling edge trigger.
 *   - Program starts with all LEDs on.
 *   - K1: low 4 LEDs and high 4 LEDs light alternately once.
 *   - K2: all LEDs blink once.
 */

#include <reg52.h>

typedef unsigned int uint;

sbit K1 = P3^2;
sbit K2 = P3^3;

void DelayMs(uint ms)
{
    uint i, j;
    for(i = 0; i < ms; i++)
    {
        for(j = 0; j < 125; j++)
        {
            ;
        }
    }
}

void LowHighAlternateOnce(void)
{
    P1 = 0xf0;     /* low 4 LEDs on, high 4 off */
    DelayMs(300);
    P1 = 0x0f;     /* high 4 LEDs on, low 4 off */
    DelayMs(300);
    P1 = 0x00;     /* all LEDs on */
}

void AllBlinkOnce(void)
{
    P1 = 0x00;     /* all on */
    DelayMs(300);
    P1 = 0xff;     /* all off */
    DelayMs(300);
    P1 = 0x00;     /* all on */
}

/* INT0 interrupt vector 0 */
void INT0_ISR(void) interrupt 0
{
    DelayMs(20);           /* debounce */
    if(K1 == 0)
    {
        LowHighAlternateOnce();
    }
}

/* INT1 interrupt vector 2 */
void INT1_ISR(void) interrupt 2
{
    DelayMs(20);           /* debounce */
    if(K2 == 0)
    {
        AllBlinkOnce();
    }
}

void main(void)
{
    P1 = 0x00;     /* active-low, all LEDs on */
    P3 = 0xff;     /* release K1/K2 input pins */

    IT0 = 1;       /* INT0 falling edge */
    IT1 = 1;       /* INT1 falling edge */
    EX0 = 1;
    EX1 = 1;
    EA  = 1;

    while(1)
    {
        ;          /* wait for interrupts */
    }
}
