/*
 * EXP03_01_SevenSeg_StudentID.c
 * Function: eight-digit dynamic scan display of student ID last 8 digits.
 * Requirement: display your student ID last 8 digits.
 * Hardware:
 *   - Insert JPSMG segment display jumper.
 *   - Remove JPP0 LED jumper to avoid affecting segment display.
 *   - P0 = segment lines, low level active.
 *   - P2 = digit select, low level active.
 *
 * Modify StudentID_Last8[] below before using.
 */

#include <reg52.h>

typedef unsigned char uchar;
typedef unsigned int  uint;

/* Common-anode segment codes, bit order: dp g f e d c b a, low active. */
uchar code SegCode[10] = {
    0xc0,  /* 0 */
    0xf9,  /* 1 */
    0xa4,  /* 2 */
    0xb0,  /* 3 */
    0x99,  /* 4 */
    0x92,  /* 5 */
    0x82,  /* 6 */
    0xf8,  /* 7 */
    0x80,  /* 8 */
    0x90   /* 9 */
};

/* Low level selects one digit. If display order is reversed, reverse this table. */
uchar code DigitSel[8] = {
    0xfe, 0xfd, 0xfb, 0xf7, 0xef, 0xdf, 0xbf, 0x7f
};

/* Example: change to your own student ID last 8 digits. */
uchar code StudentID_Last8[8] = {3,1,2,4,1,4,1,5};

void DelayMs(uint ms)
{
    uint i, j;
    for(i = 0; i < ms; i++)
    {
        for(j = 0; j < 125; j++)
        {
            ;
        }
    }
}

void DisplayOnce(void)
{
    uchar i;
    for(i = 0; i < 8; i++)
    {
        P2 = 0xff;                              /* close all digits first */
        P0 = SegCode[StudentID_Last8[i]];       /* output segment code */
        P2 = DigitSel[i];                       /* select one digit */
        DelayMs(2);
    }
}

void main(void)
{
    P0 = 0xff;
    P2 = 0xff;

    while(1)
    {
        DisplayOnce();
    }
}
