/*
 * EXP03_03_MatrixKey_Buzzer.c
 * Function: 4x4 matrix keyboard.
 * Requirement: use buzzer sound count to indicate pressed key value.
 * Hardware:
 *   - Matrix keyboard uses P1:
 *       rows: P1.0-P1.3, columns: P1.4-P1.7.
 *   - Remove JPP1 LED jumper while using matrix keyboard.
 *   - Insert JPFMG for buzzer.
 */

#include <reg52.h>

typedef unsigned char uchar;
typedef unsigned int  uint;

sbit BEEP = P3^6;

void DelayMs(uint ms)
{
    uint i, j;
    for(i = 0; i < ms; i++)
    {
        for(j = 0; j < 125; j++)
        {
            ;
        }
    }
}

void DelayUs250(uint n)
{
    uint i, j;
    for(i = 0; i < n; i++)
    {
        for(j = 0; j < 31; j++)
        {
            ;
        }
    }
}

void BeepOnce(void)
{
    uint i;
    for(i = 0; i < 180; i++)
    {
        BEEP = 0;
        DelayUs250(2);
        BEEP = 1;
        DelayUs250(2);
    }
}

void BeepTimes(uchar n)
{
    uchar i;
    for(i = 0; i < n; i++)
    {
        BeepOnce();
        DelayMs(120);
    }
}

/*
 * Return 1-16 when key is pressed, return 0 when no key.
 * Scanning order:
 *   row1: 1  2  3  4
 *   row2: 5  6  7  8
 *   row3: 9 10 11 12
 *   row4:13 14 15 16
 */
uchar MatrixKeyScan(void)
{
    uchar row, col, temp, key;

    key = 0;

    for(row = 0; row < 4; row++)
    {
        P1 = 0xff;
        P1 = P1 & (~(1 << row));       /* one row low, columns high */
        DelayMs(1);

        temp = P1 & 0xf0;
        if(temp != 0xf0)
        {
            DelayMs(20);               /* debounce */
            temp = P1 & 0xf0;
            if(temp != 0xf0)
            {
                if((temp & 0x10) == 0) col = 0;
                else if((temp & 0x20) == 0) col = 1;
                else if((temp & 0x40) == 0) col = 2;
                else col = 3;

                key = row * 4 + col + 1;

                while((P1 & 0xf0) != 0xf0)
                {
                    ;                  /* wait release */
                }

                P1 = 0xff;
                return key;
            }
        }
    }

    P1 = 0xff;
    return 0;
}

void main(void)
{
    uchar key;

    BEEP = 1;
    P1 = 0xff;

    while(1)
    {
        key = MatrixKeyScan();
        if(key != 0)
        {
            BeepTimes(key);
        }
    }
}
