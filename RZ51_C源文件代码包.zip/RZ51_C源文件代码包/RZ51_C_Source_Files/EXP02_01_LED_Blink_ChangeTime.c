/*
 * EXP02_01_LED_Blink_ChangeTime.c
 * Function: change LED blink time.
 * Requirement: modify sample LED blinking program and change flashing interval.
 */

#include <reg52.h>

typedef unsigned int uint;

#define ON_TIME_MS   200     /* change this value to modify ON time */
#define OFF_TIME_MS  800     /* change this value to modify OFF time */

void DelayMs(uint ms)
{
    uint i, j;
    for(i = 0; i < ms; i++)
    {
        for(j = 0; j < 125; j++)
        {
            ;
        }
    }
}

void main(void)
{
    P0 = 0xff;
    P1 = 0xff;

    while(1)
    {
        P0 = 0x00;
        P1 = 0x00;
        DelayMs(ON_TIME_MS);

        P0 = 0xff;
        P1 = 0xff;
        DelayMs(OFF_TIME_MS);
    }
}
