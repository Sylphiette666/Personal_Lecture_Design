/*
 * EXP02_03_Buzzer_Effect.c
 * Function: passive buzzer effect.
 * Requirement: modify sample program and change buzzer sound effect.
 * Hardware:
 *   - Insert JPFMG buzzer jumper.
 *   - P3.6 controls buzzer. Low level turns the transistor on.
 */

#include <reg52.h>

typedef unsigned int uint;

sbit BEEP = P3^6;
sbit LED0 = P0^0;

void DelayUs250(uint n)
{
    uint i, j;
    for(i = 0; i < n; i++)
    {
        for(j = 0; j < 31; j++)
        {
            ;
        }
    }
}

void DelayMs(uint ms)
{
    uint i, j;
    for(i = 0; i < ms; i++)
    {
        for(j = 0; j < 125; j++)
        {
            ;
        }
    }
}

/* Make square wave. Smaller half_period value means higher tone. */
void BeepTone(uint half_period_250us, uint cycles)
{
    uint i;
    for(i = 0; i < cycles; i++)
    {
        BEEP = 0;
        DelayUs250(half_period_250us);
        BEEP = 1;
        DelayUs250(half_period_250us);
    }
}

void main(void)
{
    P0 = 0xff;
    BEEP = 1;

    while(1)
    {
        LED0 = 0;              /* LED0 on */
        BeepTone(2, 300);      /* higher tone */
        DelayMs(100);

        LED0 = 1;              /* LED0 off */
        BeepTone(4, 200);      /* lower tone */
        DelayMs(300);
    }
}
