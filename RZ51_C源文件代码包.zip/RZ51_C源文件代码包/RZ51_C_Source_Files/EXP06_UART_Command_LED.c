/*
 * EXP06_UART_Command_LED.c
 * Function: serial communication command controls P0 LEDs.
 * Requirement:
 *   PC sends Y/N/F/R:
 *     Y -> P0 LEDs all on, return A
 *     N -> P0 LEDs all off, return A
 *     F -> P0 LEDs all on 1s, all off 1s, repeat, return A
 *     R -> P0 LEDs run one by one, interval 1s, return A
 *     other -> return "wrong command"
 *
 * Hardware:
 *   - P0 connects 8 LEDs. Insert JPP0 and JPPR0.
 *   - Serial uses P3.0 RXD and P3.1 TXD.
 *   - Baud rate 9600 bps, crystal 11.0592 MHz.
 */

#include <reg52.h>

typedef unsigned char uchar;
typedef unsigned int  uint;

#define MODE_NONE   0
#define MODE_FLASH  1
#define MODE_RUN    2

volatile uchar work_mode = MODE_NONE;

void DelayMs(uint ms)
{
    uint i, j;
    for(i = 0; i < ms; i++)
    {
        for(j = 0; j < 125; j++)
        {
            ;
        }
    }
}

void UART_Init(void)
{
    SCON = 0x50;        /* 8-bit UART, REN enabled */
    TMOD &= 0x0f;
    TMOD |= 0x20;       /* Timer1 mode 2 auto-reload */
    TH1 = 0xfd;         /* 9600 bps @ 11.0592 MHz */
    TL1 = 0xfd;
    TR1 = 1;
}

void UART_SendChar(uchar dat)
{
    SBUF = dat;
    while(TI == 0)
    {
        ;
    }
    TI = 0;
}

void UART_SendString(char *s)
{
    while(*s != '\0')
    {
        UART_SendChar((uchar)(*s));
        s++;
    }
}

void ProcessCommand(uchar cmd)
{
    if(cmd == 'Y' || cmd == 'y')
    {
        work_mode = MODE_NONE;
        P0 = 0x00;             /* all LEDs on */
        UART_SendChar('A');
    }
    else if(cmd == 'N' || cmd == 'n')
    {
        work_mode = MODE_NONE;
        P0 = 0xff;             /* all LEDs off */
        UART_SendChar('A');
    }
    else if(cmd == 'F' || cmd == 'f')
    {
        work_mode = MODE_FLASH;
        UART_SendChar('A');
    }
    else if(cmd == 'R' || cmd == 'r')
    {
        work_mode = MODE_RUN;
        UART_SendChar('A');
    }
    else
    {
        UART_SendString("wrong command\r\n");
    }
}

bit CheckUART(void)
{
    if(RI == 1)
    {
        uchar dat;
        RI = 0;
        dat = SBUF;
        ProcessCommand(dat);
        return 1;
    }
    return 0;
}

/* Delay with UART checking. Returns 1 if a new command is received. */
bit DelayMs_CheckUART(uint ms)
{
    uint i, j;
    for(i = 0; i < ms; i++)
    {
        for(j = 0; j < 125; j++)
        {
            if(RI == 1)
            {
                CheckUART();
                return 1;
            }
        }
    }
    return 0;
}

void main(void)
{
    uchar led;

    P0 = 0xff;
    UART_Init();

    while(1)
    {
        CheckUART();

        if(work_mode == MODE_FLASH)
        {
            P0 = 0x00;
            if(DelayMs_CheckUART(1000)) continue;

            P0 = 0xff;
            if(DelayMs_CheckUART(1000)) continue;
        }
        else if(work_mode == MODE_RUN)
        {
            led = 0xfe;
            while(work_mode == MODE_RUN)
            {
                P0 = led;
                if(DelayMs_CheckUART(1000)) break;

                led = (led << 1) | 0x01;
                if(led == 0xff)
                {
                    led = 0xfe;
                }
            }
        }
    }
}
