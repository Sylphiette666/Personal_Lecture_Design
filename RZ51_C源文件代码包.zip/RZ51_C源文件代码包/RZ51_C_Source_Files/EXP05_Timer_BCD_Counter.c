/*
 * EXP05_Timer_BCD_Counter.c
 * Function: simple second counter using Timer0.
 * Requirement:
 *   - P1 connects 8 LEDs and displays time in BCD code, range 00-99.
 *   - Default: auto increment from 0 every 1 second.
 *   - K1/INT0: manual add 1.
 *   - K2/INT1: manual clear to 0.
 *
 * LED is active-low, so output is inverted: P1 = ~BCD.
 * Example: 63 -> BCD 0x63, LEDs lit pattern from high to low is 0110 0011.
 *
 * Crystal assumed: 11.0592 MHz, 12T 8051.
 * Timer0 10 ms reload: 65536 - 9216 = 0xDC00.
 */

#include <reg52.h>

typedef unsigned char uchar;
typedef unsigned int  uint;

#define TIMER0_TH_10MS  0xDC
#define TIMER0_TL_10MS  0x00

sbit K1 = P3^2;
sbit K2 = P3^3;

volatile uchar sec_count = 0;
volatile uchar t0_10ms_count = 0;

uchar ToBCD(uchar value)
{
    return (uchar)(((value / 10) << 4) | (value % 10));
}

void DisplayBCD(void)
{
    P1 = (uchar)(~ToBCD(sec_count));
}

void IncSecond(void)
{
    sec_count++;
    if(sec_count >= 100)
    {
        sec_count = 0;
    }
    DisplayBCD();
}

void DelayMs(uint ms)
{
    uint i, j;
    for(i = 0; i < ms; i++)
    {
        for(j = 0; j < 125; j++)
        {
            ;
        }
    }
}

void Timer0Init(void)
{
    TMOD &= 0xf0;
    TMOD |= 0x01;          /* Timer0 mode 1: 16-bit timer */

    TH0 = TIMER0_TH_10MS;
    TL0 = TIMER0_TL_10MS;

    ET0 = 1;
    TR0 = 1;
}

/* Timer0 interrupt vector 1, every about 10 ms */
void Timer0_ISR(void) interrupt 1
{
    TH0 = TIMER0_TH_10MS;
    TL0 = TIMER0_TL_10MS;

    t0_10ms_count++;
    if(t0_10ms_count >= 100)   /* 100 * 10 ms = 1 s */
    {
        t0_10ms_count = 0;
        IncSecond();
    }
}

/* K1: manual add */
void INT0_ISR(void) interrupt 0
{
    DelayMs(20);
    if(K1 == 0)
    {
        IncSecond();
        while(K1 == 0)
        {
            ;
        }
    }
}

/* K2: manual clear */
void INT1_ISR(void) interrupt 2
{
    DelayMs(20);
    if(K2 == 0)
    {
        sec_count = 0;
        t0_10ms_count = 0;
        DisplayBCD();
        while(K2 == 0)
        {
            ;
        }
    }
}

void main(void)
{
    P1 = 0xff;
    P3 = 0xff;

    sec_count = 0;
    DisplayBCD();

    IT0 = 1;       /* falling edge */
    IT1 = 1;
    EX0 = 1;
    EX1 = 1;

    Timer0Init();

    EA = 1;

    while(1)
    {
        ;
    }
}
