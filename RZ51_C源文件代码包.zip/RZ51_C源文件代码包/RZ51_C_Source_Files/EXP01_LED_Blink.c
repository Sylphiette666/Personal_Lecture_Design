/*
 * EXP01_LED_Blink.c
 * RZ-51/AVR V2.8 + STC89C52 / AT89S52, Keil C51
 * Function: first Keil C51 program, P0 and P1 LEDs blink.
 * Hardware:
 *   - Insert JPP0 and JPP1 LED jumpers.
 *   - P0/P1 LEDs on this board are active-low: output 0 = ON, output 1 = OFF.
 *   - If using P0 LEDs, insert P0 pull-up jumper JPPR0.
 */

#include <reg52.h>

typedef unsigned char uchar;
typedef unsigned int  uint;

void DelayMs(uint ms)
{
    uint i, j;
    for(i = 0; i < ms; i++)
    {
        for(j = 0; j < 125; j++)
        {
            ;
        }
    }
}

void main(void)
{
    P0 = 0xff;      /* all P0 LEDs off */
    P1 = 0xff;      /* all P1 LEDs off */

    while(1)
    {
        P0 = 0x00;  /* all P0 LEDs on */
        P1 = 0x00;  /* all P1 LEDs on */
        DelayMs(500);

        P0 = 0xff;  /* all P0 LEDs off */
        P1 = 0xff;  /* all P1 LEDs off */
        DelayMs(500);
    }
}
