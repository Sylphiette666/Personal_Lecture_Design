/*
 * EXP03_02_Key_LED_Buzzer.c
 * Function: independent keys K1-K8.
 * Requirement:
 *   Press K1 -> 1 LED on, K2 -> 2 LEDs on, ..., K8 -> 8 LEDs on;
 *   buzzer sounds once when a key is pressed.
 * Hardware:
 *   - K1=P3.2, K2=P3.3, K3=P3.4, K4=P3.5, K5=P1.4, K6=P1.5, K7=P1.6, K8=P1.7.
 *   - P0 is used for LED display to avoid conflict with K5-K8 on P1.
 *   - Insert JPP0 and JPPR0; remove/avoid JPSMG and LCD.
 *   - Insert JPFMG for buzzer.
 */

#include <reg52.h>

typedef unsigned char uchar;
typedef unsigned int  uint;

sbit K1 = P3^2;
sbit K2 = P3^3;
sbit K3 = P3^4;
sbit K4 = P3^5;
sbit K5 = P1^4;
sbit K6 = P1^5;
sbit K7 = P1^6;
sbit K8 = P1^7;
sbit BEEP = P3^6;

uchar code LedCountCode[9] = {
    0xff,  /* 0 LED on */
    0xfe,  /* 1 LED on */
    0xfc,  /* 2 LEDs on */
    0xf8,  /* 3 LEDs on */
    0xf0,  /* 4 LEDs on */
    0xe0,  /* 5 LEDs on */
    0xc0,  /* 6 LEDs on */
    0x80,  /* 7 LEDs on */
    0x00   /* 8 LEDs on */
};

void DelayMs(uint ms)
{
    uint i, j;
    for(i = 0; i < ms; i++)
    {
        for(j = 0; j < 125; j++)
        {
            ;
        }
    }
}

void DelayUs250(uint n)
{
    uint i, j;
    for(i = 0; i < n; i++)
    {
        for(j = 0; j < 31; j++)
        {
            ;
        }
    }
}

void BeepOnce(void)
{
    uint i;
    for(i = 0; i < 250; i++)
    {
        BEEP = 0;
        DelayUs250(2);
        BEEP = 1;
        DelayUs250(2);
    }
}

uchar KeyScan(void)
{
    P1 = 0xff;    /* make P1.4-P1.7 input high for K5-K8 */

    if(K1 == 0) { DelayMs(20); if(K1 == 0) { while(K1 == 0); return 1; } }
    if(K2 == 0) { DelayMs(20); if(K2 == 0) { while(K2 == 0); return 2; } }
    if(K3 == 0) { DelayMs(20); if(K3 == 0) { while(K3 == 0); return 3; } }
    if(K4 == 0) { DelayMs(20); if(K4 == 0) { while(K4 == 0); return 4; } }
    if(K5 == 0) { DelayMs(20); if(K5 == 0) { while(K5 == 0); return 5; } }
    if(K6 == 0) { DelayMs(20); if(K6 == 0) { while(K6 == 0); return 6; } }
    if(K7 == 0) { DelayMs(20); if(K7 == 0) { while(K7 == 0); return 7; } }
    if(K8 == 0) { DelayMs(20); if(K8 == 0) { while(K8 == 0); return 8; } }

    return 0;
}

void main(void)
{
    uchar key;

    P0 = 0xff;
    P1 = 0xff;
    BEEP = 1;

    while(1)
    {
        key = KeyScan();
        if(key != 0)
        {
            P0 = LedCountCode[key];
            BeepOnce();
        }
    }
}
