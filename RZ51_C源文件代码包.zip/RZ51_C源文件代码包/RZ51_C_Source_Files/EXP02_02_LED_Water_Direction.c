/*
 * EXP02_02_LED_Water_Direction.c
 * Function: LED running-water effect, direction changes automatically.
 * Requirement: modify sample program and change running direction.
 * Hardware: insert JPP0/JPP1. LED is active-low.
 */

#include <reg52.h>

typedef unsigned char uchar;
typedef unsigned int  uint;

void DelayMs(uint ms)
{
    uint i, j;
    for(i = 0; i < ms; i++)
    {
        for(j = 0; j < 125; j++)
        {
            ;
        }
    }
}

void main(void)
{
    uchar i;
    uchar led;

    while(1)
    {
        /* Direction 1: bit0 -> bit7. A 0 bit means the LED is ON. */
        led = 0xfe;
        for(i = 0; i < 8; i++)
        {
            P0 = led;
            P1 = led;
            DelayMs(200);
            led = (led << 1) | 0x01;
        }

        /* Direction 2: bit7 -> bit0. */
        led = 0x7f;
        for(i = 0; i < 8; i++)
        {
            P0 = led;
            P1 = led;
            DelayMs(200);
            led = (led >> 1) | 0x80;
        }
    }
}
