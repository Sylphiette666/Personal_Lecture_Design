RZ51 C 源文件说明
================

本压缩包重新提供 .c 源文件，适用于 Keil C51、STC89C52 / AT89S52、RZ-51/AVR V2.8 学习板。

文件清单：
1. EXP01_LED_Blink.c
2. EXP02_01_LED_Blink_ChangeTime.c
3. EXP02_02_LED_Water_Direction.c
4. EXP02_03_Buzzer_Effect.c
5. EXP02_04_Relay_C_Optional.c
6. EXP03_01_SevenSeg_StudentID.c
7. EXP03_02_Key_LED_Buzzer.c
8. EXP03_03_MatrixKey_Buzzer.c
9. EXP04_01_EXTI_NoPriority.c
10. EXP04_02_EXTI_Priority.c
11. EXP05_Timer_BCD_Counter.c
12. EXP06_UART_Command_LED.c

使用方法：
1. 在 Keil C51 中新建工程，芯片可选 AT89S52 或 STC89C52。
2. 每次只添加一个 .c 源文件到工程中编译，避免多个 main() 冲突。
3. 在 Options for Target 中勾选 Create HEX File。
4. 编译后用 STC-ISP 或 USBISP 下载到学习板。

硬件注意：
- LED 为低电平点亮，程序中 0 表示亮，1 表示灭。
- P0 做 LED 或数码管段选时，需要根据实验插好对应跳线和 P0 上拉。
- 数码管实验请插 JPSMG，并拔掉 JPP0，避免 P0 LED 干扰显示。
- 蜂鸣器实验请插 JPFMG。
- 继电器实验请插 JPJDQ。
- 矩阵键盘使用 P1 口时，建议拔掉 JPP1，避免 P1 LED 干扰按键扫描。
- 串口实验默认 11.0592MHz 晶振、9600bps。
