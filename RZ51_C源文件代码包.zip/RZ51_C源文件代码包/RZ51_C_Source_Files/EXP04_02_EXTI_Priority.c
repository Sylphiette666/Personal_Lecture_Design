/*
 * EXP04_02_EXTI_Priority.c
 * Function: external interrupt experiment with priority.
 * Requirement:
 *   - Set INT1 priority higher than INT0.
 *   - When K1 action is running, pressing K2 should interrupt it,
 *     blink all LEDs once, then return to K1 action.
 */

#include <reg52.h>

typedef unsigned int uint;

sbit K1 = P3^2;
sbit K2 = P3^3;

void DelayMs(uint ms)
{
    uint i, j;
    for(i = 0; i < ms; i++)
    {
        for(j = 0; j < 125; j++)
        {
            ;
        }
    }
}

void LowHighAlternateOnce(void)
{
    P1 = 0xf0;     /* low 4 on */
    DelayMs(500);
    P1 = 0x0f;     /* high 4 on */
    DelayMs(500);
    P1 = 0x00;     /* all on */
}

void AllBlinkOnce(void)
{
    P1 = 0x00;
    DelayMs(300);
    P1 = 0xff;
    DelayMs(300);
    P1 = 0x00;
}

/* Low-priority INT0 */
void INT0_ISR(void) interrupt 0
{
    DelayMs(20);
    if(K1 == 0)
    {
        LowHighAlternateOnce();
    }
}

/* High-priority INT1 */
void INT1_ISR(void) interrupt 2
{
    DelayMs(20);
    if(K2 == 0)
    {
        AllBlinkOnce();
    }
}

void main(void)
{
    P1 = 0x00;
    P3 = 0xff;

    IT0 = 1;
    IT1 = 1;

    PX0 = 0;       /* INT0 low priority */
    PX1 = 1;       /* INT1 high priority */

    EX0 = 1;
    EX1 = 1;
    EA  = 1;

    while(1)
    {
        ;
    }
}
