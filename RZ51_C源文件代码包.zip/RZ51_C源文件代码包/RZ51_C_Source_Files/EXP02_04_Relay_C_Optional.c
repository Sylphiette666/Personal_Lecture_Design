/*
 * EXP02_04_Relay_C_Optional.c
 * Function: relay control in C language.
 * Note: task says relay control can be done in assembly as optional.
 *       This C version is provided for reference.
 * Hardware:
 *   - Insert JPJDQ relay jumper.
 *   - P3.7 controls relay. Low level = relay ON, high level = relay OFF.
 */

#include <reg52.h>

typedef unsigned int uint;

sbit RELAY = P3^7;
sbit LED0  = P0^0;

void DelayMs(uint ms)
{
    uint i, j;
    for(i = 0; i < ms; i++)
    {
        for(j = 0; j < 125; j++)
        {
            ;
        }
    }
}

void main(void)
{
    P0 = 0xff;
    RELAY = 1;          /* relay off */

    while(1)
    {
        RELAY = 0;      /* relay on */
        LED0 = 0;
        DelayMs(1000);

        RELAY = 1;      /* relay off */
        LED0 = 1;
        DelayMs(1000);
    }
}
