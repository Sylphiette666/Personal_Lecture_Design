﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ContactMS
{
    public partial class admin_2_1 : Form
    {
        public admin_2_1()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }



        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void admin_2_1_Load(object sender, EventArgs e)
        {

        }

        private void admin_2_1_Load_1(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (textBox_Id.Text != "" && textBox_Name.Text != "" && textBox_Address.Text != "" && textBox_Sex.Text != "" && textBox_Phonenumber.Text != "")
            {
                Dao dao = new Dao();
                string sql = $"Insert into t_Contact values('{textBox_Id.Text}','{textBox_Name.Text}','{textBox_Sex.Text}','{textBox_Address.Text}','{textBox_Email.Text}','{textBox_Phonenumber.Text}')";
                int n = dao.Execute(sql);
                if (n > 0)
                {
                    MessageBox.Show("添加成功！");
                }
                else
                {
                    MessageBox.Show("添加失败！！！");
                }
                textBox_Id.Text = "";
                textBox_Name.Text = "";
                textBox_Sex.Text = "";
                textBox_Address.Text = "";
                textBox_Email.Text = "";
                textBox_Phonenumber.Text = "";
            }
            else
            {
                MessageBox.Show("除电子邮件外不允许空值！！！");
            }
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            textBox_Id.Text = "";
            textBox_Name.Text = "";
            textBox_Sex.Text = "";
            textBox_Address.Text = "";
            textBox_Email.Text = "";
            textBox_Phonenumber.Text = "";
        }

        private void textBox_Phonenumber_TextChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void textBox_Email_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click_1(object sender, EventArgs e)
        {

        }

        private void textBox_Address_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void textBox_Sex_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox_Name_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox_Id_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
