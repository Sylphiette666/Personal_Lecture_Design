﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ContactMS
{
    public partial class user_2 : Form
    {
        public user_2()
        {
            InitializeComponent();
            Table();
        }

        private void user_2_Load(object sender, EventArgs e)
        {

        }
        public void Table()
        {
            dataGridView1.Rows.Clear();//清空已有数据
            Dao dao = new Dao();
            string sql = "select * from t_Contact";
            IDataReader dc = dao.read(sql);
            string Id, Name, Sex, Address, Email, Phonenumber;
            while (dc.Read())
            {
                Id = dc[0].ToString();
                Name = dc[1].ToString();
                Sex = dc[2].ToString();
                Address = dc[3].ToString();
                Email = dc[4].ToString();
                Phonenumber = dc[5].ToString();
                string[] table = { Id, Name, Sex, Address, Email, Phonenumber };
                dataGridView1.Rows.Add(table);
            }
            dc.Close();
            dao.Daoclose();
        }
    }
}
