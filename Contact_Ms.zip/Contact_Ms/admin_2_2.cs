﻿using ContactMS;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Contact_Ms
{
    public partial class admin_2_2 : Form
    {
        public admin_2_2()
        {
            InitializeComponent();
        }
        public admin_2_2(string Id,string Name,string Sex,string Address,string Email,string Phonenumber)
        {
            InitializeComponent();
            textBox_Id.Text = Id;
            textBox_Name.Text = Name;
            textBox_Sex.Text = Sex;
            textBox_Address.Text = Address;
            textBox_Email.Text = Email;
            textBox_Phonenumber.Text = Phonenumber;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            string sql = $"update t_Contact set Id='{textBox_Id.Text}',Name='{textBox_Name.Text}',Sex='{textBox_Sex.Text}',Address='{textBox_Address.Text}',Email='{textBox_Email.Text}',Phonenumber='{textBox_Phonenumber.Text}' where Id='{textBox_Id.Text}'";
            Dao dao = new Dao();
            if(dao.Execute(sql)>0)
            {
                MessageBox.Show("修改成功！");
                this.Close();
            }
            else
            {
                MessageBox.Show("修改失败！！！（除电子邮箱外不允许空值！）");
                this.Close();
            }
        }
    }
}
