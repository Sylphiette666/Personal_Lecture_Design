﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace ContactMS
{
    public partial class user_1_1 : Form
    {
        public user_1_1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button_Password_Click(object sender, EventArgs e)
        {
            string sql = $"update t_User set Password='{textBox_Paaaword.Text}' where Id='{textBox1.Text}'";
            Dao dao = new Dao();
            if (dao.Execute(sql) > 0)
            {
                MessageBox.Show("修改成功！");
                this.Close();
            }
            else
            {
                MessageBox.Show("修改失败！！！（Id不为空！）");
                this.Close();
            }
        }
    }
}
