﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ContactMS
{
    public partial class Register : Form
    {
        public Register()
        {
            InitializeComponent();
        }



        private void button1_Click_1(object sender, EventArgs e)
        {
            if (radioButton_register_user.Checked == true)
            {
                if (textBox_Id.Text != "" && textBox_Name.Text != "" && textBox_Sex.Text != "" && textBox_Password.Text != "")
                {
                    Dao dao = new Dao();
                    string sql = $"Insert into t_User values('{textBox_Id.Text}','{textBox_Name.Text}','{textBox_Sex.Text}','{textBox_Password.Text}')";
                    int n = dao.Execute(sql);
                    if (n > 0)
                    {
                        MessageBox.Show("添加成功！");
                    }
                    else
                    {
                        MessageBox.Show("添加失败！！！");
                    }
                    textBox_Id.Text = "";
                    textBox_Name.Text = "";
                    textBox_Sex.Text = "";
                    textBox_Password.Text = "";
                }
                else
                {
                    MessageBox.Show("不允许空值！！！");
                }
            }
            else if (radioButton_register_admin.Checked == true)
            {
                if (textBox_Id.Text != "" && textBox_Name.Text == "" && textBox_Sex.Text == "" && textBox_Password.Text != "")
                {
                    Dao dao = new Dao();
                    string sql = $"Insert into t_Admin values('{textBox_Id.Text}','{textBox_Password.Text}')";
                    int n = dao.Execute(sql);
                    if (n > 0)
                    {
                        MessageBox.Show("添加成功！");
                    }
                    else
                    {
                        MessageBox.Show("添加失败！！！");
                    }
                    textBox_Id.Text = "";
                    textBox_Password.Text = "";
                }
                else
                {
                    MessageBox.Show("不允许空值！！！");
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox_Id.Text = "";
            textBox_Name.Text = "";
            textBox_Sex.Text = "";
            textBox_Password.Text = "";
        }
    }
}
