﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ContactMS
{
    public partial class user_1_2 : Form
    {
        public user_1_2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            string sql = $"delete t_User where Id='{textBox_delete.Text}'";
            Dao dao = new Dao();
            if (dao.Execute(sql) > 0)
            {
                MessageBox.Show("删除成功！");
                this.Close();
            }
            else
            {
                MessageBox.Show("删除失败！！！（ID不为空！）");
                this.Close();
            }
        }
    }
}
