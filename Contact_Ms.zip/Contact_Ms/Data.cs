﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContactMS
{
    internal class Data
    {
        public static string Id = "", Name = "";//登陆用户的id和姓名
    }
}
