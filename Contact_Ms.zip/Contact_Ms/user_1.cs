﻿using Contact_Ms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ContactMS
{
    public partial class user_1 : Form
    {
        public user_1()
        {
            InitializeComponent();
        }

        private void 修改密码ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void 查看联系人ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            user_2 user =new user_2();
            user.ShowDialog();
        }

        private void 删除用户ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            user_1_2 user = new user_1_2();
            user.ShowDialog();
        }

        private void 修改密码ToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            user_1_1 user = new user_1_1();
            user.ShowDialog();
        }

        private void 退出ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void 帮助ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            help help = new help();
            help.ShowDialog();
        }
    }
}
