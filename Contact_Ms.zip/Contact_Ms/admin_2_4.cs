﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ContactMS
{
    public partial class admin_2_4 : Form
    {
        public admin_2_4()
        {
            InitializeComponent();
        }


        private void button1_Click_1(object sender, EventArgs e)
        {
            string sql = $"delete t_Admin where Id='{textBox_delete.Text}'";
            Dao dao = new Dao();
            if (dao.Execute(sql) > 0)
            {
                MessageBox.Show("删除成功！");
                this.Close();
            }
        }
    }
}
