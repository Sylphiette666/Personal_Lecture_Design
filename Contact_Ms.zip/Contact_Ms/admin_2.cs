﻿using Contact_Ms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ContactMS
{
    public partial class admin_2 : Form
    {
        public admin_2()
        {
            InitializeComponent();
        }

        private void admin_2_Load(object sender, EventArgs e)
        {
            Table();
        }
        //从数据库读取数据显示在表格中
        public void Table()
        {
            dataGridView1.Rows.Clear();//清空已有数据
            Dao dao = new Dao();
            string sql = "select * from t_Contact";
            IDataReader dc = dao.read(sql);
            string Id, Name, Sex, Address, Email, Phonenumber;
            while (dc.Read())
            {
                Id = dc[0].ToString();
                Name = dc[1].ToString();
                Sex = dc[2].ToString();
                Address = dc[3].ToString();
                Email = dc[4].ToString();
                Phonenumber = dc[5].ToString();
                string[] table = { Id, Name, Sex, Address, Email, Phonenumber };
                dataGridView1.Rows.Add(table);
            }
            dc.Close();
            dao.Daoclose();
        }

        //查询联系人
        public void Select()
        {
            dataGridView1.Rows.Clear();//清空已有数据
            Dao dao = new Dao();
            string sql = $"select * from t_Contact  ";
            if (textBox_Check_Id.Text!="")
            {
                sql += $"where Id='{textBox_Check_Id.Text}'";
            }
            if (textBox_Check_Name.Text != "")
            {
                sql += $" and Name ='{textBox_Check_Name.Text}'";
            }
            if (textBox_Check_Sex.Text != "")
            {
                sql += $" and Sex='{textBox_Check_Sex.Text}'";
            }
            if (textBox_Check_Address.Text != "")
            {
                sql += $" and Address ='{textBox_Check_Address.Text}'";
            }
            if (textBox_Check_Email.Text != "")
            {
                sql += $" and Email = '{textBox_Check_Email.Text}'";
            }
            if (textBox_Check_Phonenumber.Text != "")
            {
                sql += $" and Phonenumber = '{textBox_Check_Phonenumber.Text}'";
            }
            IDataReader dc = dao.read(sql);
            string Id, Name, Sex, Address, Email, Phonenumber;
            while (dc.Read())
            {
                Id = dc[0].ToString();
                Name = dc[1].ToString();
                Sex = dc[2].ToString();
                Address = dc[3].ToString();
                Email = dc[4].ToString();
                Phonenumber = dc[5].ToString();
                string[] table = { Id, Name, Sex, Address, Email, Phonenumber };
                dataGridView1.Rows.Add(table);
            }
            dc.Close();
            dao.Daoclose();
        }
        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                string id = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();//获取要删除的联系人的序号
                label_choosed.Text = id + dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
                DialogResult dr = MessageBox.Show("是否删除？", "信息提示", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (dr == DialogResult.Yes)
                {
                    string sql = $"delete from t_Contact where Id='{id}'";
                    Dao dao = new Dao();
                    if (dao.Execute(sql) > 0)
                    {
                        MessageBox.Show("删除成功！");
                        Table();
                    }
                    else
                    {
                        MessageBox.Show("删除失败！！！" + sql);
                    }
                    dao.Daoclose();
                }
            }
            catch
            {
                MessageBox.Show("请先在表格中选中要删除的联系人！", "信息提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void dataGridView1_Click(object sender, EventArgs e)
        {
            label_choosed.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString() + dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            admin_2_1 a = new admin_2_1();
            a.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                string Id = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                string Name = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
                string Sex = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
                string Address = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
                string Eamil = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
                string Phonenumber = dataGridView1.SelectedRows[0].Cells[5].Value.ToString();
                admin_2_2 admin = new admin_2_2();
                admin.ShowDialog();
                Table();//刷新数据
            }
            catch
            {
                MessageBox.Show("Error!!!");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Select();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            Table();
            textBox_Check_Id.Text = textBox_Check_Name.Text = textBox_Check_Sex.Text = textBox_Check_Phonenumber.Text = textBox_Check_Email.Text = textBox_Check_Address.Text = "";
        }

        private void admin_2_Load_1(object sender, EventArgs e)
        {

        }


    }
}
