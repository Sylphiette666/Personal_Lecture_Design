﻿using ContactMS;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Contact_Ms
{
    public partial class admin_2_3 : Form
    {
        public admin_2_3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sql = $"update t_Admin set Password='{textBox_Paaaword.Text}' where Id='{textBox1.Text}'";
            Dao dao = new Dao();
            if (dao.Execute(sql) > 0)
            {
                MessageBox.Show("修改成功！");
                this.Close();
            }
        }

        private void admin_2_3_Load(object sender, EventArgs e)
        {

        }
    }
}
