﻿using Contact_Ms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ContactMS
{
    public partial class admin_1 : Form
    {
        public admin_1()
        {
            InitializeComponent();
        }

        private void admin_1_Load(object sender, EventArgs e)
        {

        }

        private void 通讯录管理ToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            admin_2 admin = new admin_2();
            admin.ShowDialog();
        }

        private void 修改密码ToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            admin_2_3 admin = new admin_2_3();
            admin.ShowDialog();
        }

        private void 删除用户ToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            admin_2_4 admin = new admin_2_4();
            admin.ShowDialog();
        }

        private void 退出ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void 帮助ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            help help = new help();
            help.ShowDialog();
        }
    }
}
