﻿namespace ContactMS
{
    partial class user_1_1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(user_1_1));
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button_Password = new System.Windows.Forms.Button();
            this.textBox_Paaaword = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(304, 121);
            this.textBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(344, 25);
            this.textBox1.TabIndex = 43;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("华文行楷", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(127, 122);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(171, 24);
            this.label1.TabIndex = 42;
            this.label1.Text = "要修改的账户：";
            // 
            // button_Password
            // 
            this.button_Password.Location = new System.Drawing.Point(200, 224);
            this.button_Password.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button_Password.Name = "button_Password";
            this.button_Password.Size = new System.Drawing.Size(448, 83);
            this.button_Password.TabIndex = 41;
            this.button_Password.Text = "修改密码";
            this.button_Password.UseVisualStyleBackColor = true;
            this.button_Password.Click += new System.EventHandler(this.button_Password_Click);
            // 
            // textBox_Paaaword
            // 
            this.textBox_Paaaword.Location = new System.Drawing.Point(304, 170);
            this.textBox_Paaaword.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_Paaaword.Name = "textBox_Paaaword";
            this.textBox_Paaaword.Size = new System.Drawing.Size(344, 25);
            this.textBox_Paaaword.TabIndex = 40;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("华文行楷", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label6.Location = new System.Drawing.Point(196, 171);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(102, 24);
            this.label6.TabIndex = 39;
            this.label6.Text = "新密码：";
            // 
            // user_1_1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button_Password);
            this.Controls.Add(this.textBox_Paaaword);
            this.Controls.Add(this.label6);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "user_1_1";
            this.Text = "修改密码";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button_Password;
        private System.Windows.Forms.TextBox textBox_Paaaword;
        private System.Windows.Forms.Label label6;
    }
}