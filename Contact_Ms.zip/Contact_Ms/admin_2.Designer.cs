﻿namespace ContactMS
{
    partial class admin_2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(admin_2));
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.textBox_Check_Id = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label_choosed = new System.Windows.Forms.Label();
            this.textBox_Check_Name = new System.Windows.Forms.TextBox();
            this.textBox_Check_Sex = new System.Windows.Forms.TextBox();
            this.textBox_Check_Address = new System.Windows.Forms.TextBox();
            this.textBox_Check_Email = new System.Windows.Forms.TextBox();
            this.textBox_Check_Phonenumber = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6});
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Left;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 30;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(855, 497);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.Click += new System.EventHandler(this.dataGridView1_Click);
            // 
            // Column1
            // 
            this.Column1.HeaderText = "序号";
            this.Column1.MinimumWidth = 3;
            this.Column1.Name = "Column1";
            this.Column1.Width = 75;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "名字";
            this.Column2.MinimumWidth = 6;
            this.Column2.Name = "Column2";
            this.Column2.Width = 125;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "性别";
            this.Column3.MinimumWidth = 6;
            this.Column3.Name = "Column3";
            this.Column3.Width = 50;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "地址";
            this.Column4.MinimumWidth = 6;
            this.Column4.Name = "Column4";
            this.Column4.Width = 200;
            // 
            // Column5
            // 
            this.Column5.HeaderText = "电子邮箱";
            this.Column5.MinimumWidth = 6;
            this.Column5.Name = "Column5";
            this.Column5.Width = 200;
            // 
            // Column6
            // 
            this.Column6.HeaderText = "电话";
            this.Column6.MinimumWidth = 6;
            this.Column6.Name = "Column6";
            this.Column6.Width = 200;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(953, 27);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(193, 66);
            this.button1.TabIndex = 1;
            this.button1.Text = "添加联系人";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(1103, 132);
            this.button2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(107, 171);
            this.button2.TabIndex = 2;
            this.button2.Text = "查询联系人";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(976, 338);
            this.button3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(107, 38);
            this.button3.TabIndex = 3;
            this.button3.Text = "修改联系人";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(976, 390);
            this.button4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(107, 38);
            this.button4.TabIndex = 4;
            this.button4.Text = "删除联系人";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(976, 448);
            this.button5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(107, 38);
            this.button5.TabIndex = 5;
            this.button5.Text = "刷新";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // textBox_Check_Id
            // 
            this.textBox_Check_Id.AccessibleName = "";
            this.textBox_Check_Id.BackColor = System.Drawing.SystemColors.Window;
            this.textBox_Check_Id.Location = new System.Drawing.Point(976, 132);
            this.textBox_Check_Id.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_Check_Id.Name = "textBox_Check_Id";
            this.textBox_Check_Id.Size = new System.Drawing.Size(121, 25);
            this.textBox_Check_Id.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(973, 115);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(127, 15);
            this.label2.TabIndex = 8;
            this.label2.Text = "当前选中联系人：";
            // 
            // label_choosed
            // 
            this.label_choosed.AutoSize = true;
            this.label_choosed.ForeColor = System.Drawing.Color.Blue;
            this.label_choosed.Location = new System.Drawing.Point(1107, 115);
            this.label_choosed.Name = "label_choosed";
            this.label_choosed.Size = new System.Drawing.Size(39, 15);
            this.label_choosed.TabIndex = 9;
            this.label_choosed.Text = "NULL";
            // 
            // textBox_Check_Name
            // 
            this.textBox_Check_Name.Location = new System.Drawing.Point(976, 161);
            this.textBox_Check_Name.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_Check_Name.Name = "textBox_Check_Name";
            this.textBox_Check_Name.Size = new System.Drawing.Size(121, 25);
            this.textBox_Check_Name.TabIndex = 10;
            // 
            // textBox_Check_Sex
            // 
            this.textBox_Check_Sex.Location = new System.Drawing.Point(976, 190);
            this.textBox_Check_Sex.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_Check_Sex.Name = "textBox_Check_Sex";
            this.textBox_Check_Sex.Size = new System.Drawing.Size(121, 25);
            this.textBox_Check_Sex.TabIndex = 11;
            // 
            // textBox_Check_Address
            // 
            this.textBox_Check_Address.Location = new System.Drawing.Point(976, 219);
            this.textBox_Check_Address.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_Check_Address.Name = "textBox_Check_Address";
            this.textBox_Check_Address.Size = new System.Drawing.Size(121, 25);
            this.textBox_Check_Address.TabIndex = 12;
            // 
            // textBox_Check_Email
            // 
            this.textBox_Check_Email.Location = new System.Drawing.Point(976, 248);
            this.textBox_Check_Email.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_Check_Email.Name = "textBox_Check_Email";
            this.textBox_Check_Email.Size = new System.Drawing.Size(121, 25);
            this.textBox_Check_Email.TabIndex = 13;
            // 
            // textBox_Check_Phonenumber
            // 
            this.textBox_Check_Phonenumber.Location = new System.Drawing.Point(976, 278);
            this.textBox_Check_Phonenumber.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_Check_Phonenumber.Name = "textBox_Check_Phonenumber";
            this.textBox_Check_Phonenumber.Size = new System.Drawing.Size(121, 25);
            this.textBox_Check_Phonenumber.TabIndex = 14;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(947, 135);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(31, 15);
            this.label1.TabIndex = 15;
            this.label1.Text = "Id:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(931, 164);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 15);
            this.label3.TabIndex = 16;
            this.label3.Text = "Name:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(939, 193);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(39, 15);
            this.label4.TabIndex = 17;
            this.label4.Text = "Sex:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(907, 222);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(71, 15);
            this.label5.TabIndex = 18;
            this.label5.Text = "Address:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(923, 251);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(55, 15);
            this.label6.TabIndex = 19;
            this.label6.Text = "Email:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(875, 281);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(103, 15);
            this.label7.TabIndex = 20;
            this.label7.Text = "Phonenumber:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.Red;
            this.label8.Location = new System.Drawing.Point(943, 321);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(203, 15);
            this.label8.TabIndex = 21;
            this.label8.Text = "注：查询联系人必须填写ID！";
            // 
            // admin_2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1223, 497);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox_Check_Phonenumber);
            this.Controls.Add(this.textBox_Check_Email);
            this.Controls.Add(this.textBox_Check_Address);
            this.Controls.Add(this.textBox_Check_Sex);
            this.Controls.Add(this.textBox_Check_Name);
            this.Controls.Add(this.label_choosed);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox_Check_Id);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dataGridView1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "admin_2";
            this.Text = "通讯录管理子页面";
            this.Load += new System.EventHandler(this.admin_2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.TextBox textBox_Check_Id;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label_choosed;
        private System.Windows.Forms.TextBox textBox_Check_Name;
        private System.Windows.Forms.TextBox textBox_Check_Sex;
        private System.Windows.Forms.TextBox textBox_Check_Address;
        private System.Windows.Forms.TextBox textBox_Check_Email;
        private System.Windows.Forms.TextBox textBox_Check_Phonenumber;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
    }
}